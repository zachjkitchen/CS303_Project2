//Project 2

#include "BTNode.h"

using namespace std;


BTNode::BTNode(BTNode* leftChild, BTNode* rightChild, char letter, string path) {
	left = leftChild;
	right = rightChild;
	data = letter;
	Path = path;
}

char BTNode::getData() {
	return data;
}

void BTNode::setData(char letter) {
	data = letter;
}