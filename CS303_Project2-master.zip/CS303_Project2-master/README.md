# CS303_Project2

Hi.

This project is NOT using precompiled headers.

After cloning the project you may need to right-click the project in your solution explorer, 
navigate to properties -> c++ -> precompiled headers,
select "not using precompiled headers" 
